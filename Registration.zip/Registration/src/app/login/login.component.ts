import { Component, OnInit } from '@angular/core';
//import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators, Form} from '@angular/forms';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  loginForm!: FormGroup;
  registerForm!:FormGroup

  submitted = false;
  email: any;
  password: any;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
 
    });
  }


  get registerFormControl() {
    return this.registerForm.controls;
  }
      
  onSubmit()
{
  alert("submit method is work");

     this.submitted=true;
       console.log("Somthing will happend");
     console.log("Email is:"+this.registerForm.value.email);
    //  localStorage.setItem('FirstName',this.registerForm.value.firstName)
    //  localStorage.setItem('LastName',this.registerForm.value.lastName)
    //  localStorage.setItem('DateOfBirth',this.registerForm.value.dateOfBirth)
    //  localStorage.setItem('Email',this.registerForm.value.email)
    //  localStorage.setItem('Password',this.registerForm.value.password)
}

}
