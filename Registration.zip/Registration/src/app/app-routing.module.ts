import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DeshboardComponent } from './deshboard/deshboard.component';
import { Desh3Component } from './desh3/desh3.component';



const routes: Routes = [
  {
    path:"Login",
  component:LoginComponent
  },
  {
    path:"Deshb",
    component:DeshboardComponent
  },
  {
    path:"Desh3",
    component:Desh3Component
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
