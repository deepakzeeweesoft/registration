import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';

import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from  '@angular/forms';

import { LoginComponent } from './login/login.component';
import { DeshboardComponent } from './deshboard/deshboard.component';
import { Desh3Component } from './desh3/desh3.component';



// import { MatDatepickerModule } from '@angular/material/datepicker';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatNativeDateModule } from '@angular/material/core';


@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    LoginComponent,
    DeshboardComponent,
    Desh3Component,
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
  //  BsDatepickerModule.forRoot(),    
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: FormComponent },
      { path: 'reactive-form', component: FormComponent }
    ]),
    
    ReactiveFormsModule,
    // MatDatepickerModule,
    // MatFormFieldModule,
    // MatNativeDateModule
 
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
