import { Component, OnInit } from '@angular/core';
import {ServicescustomvalidationService} from '../servicescustomvalidation.service'
import {FormBuilder,FormGroup,Validators} from '@angular/forms'


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;

  data:any=[]
    //for datepicker
    public date: Date = new Date(); 
  formBuilder: any;

  constructor(private fb: FormBuilder,
    private customValidator: ServicescustomvalidationService) { }

  ngOnInit() {
   this.registerForm = this.fb.group({    
    name: ['', Validators.required],     
      firstName: ['', Validators.required],
    lastName: ['', Validators.required],
   dateOfBirth:['',Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.compose([Validators.required, this.customValidator.patternValidator()])],
      confirmPassword: ['', [Validators.required]],
    },
      {
        validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
      }
    );
  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

  onSubmit() {

   alert("sotfdgdh")
    this.data.push({firstName : this.registerForm.value.firstName,
                   lastName : this.registerForm.value.lastName,
                  dateOfBirth: this.registerForm.value.dateOfBirth,
                   email: this.registerForm.value.email,
                   password:this.registerForm.value.password,
                  //  confirmPassword:this.registerForm.value.confirmPassword,
                   name:this.registerForm.value.name 
                  })

   
    this.submitted = true;
    if (this.registerForm.valid) {
      alert('Form Submitted succesfully!!!');
      console.table(this.registerForm.value);
    }

    this.submitted = true;

    localStorage.setItem('FirstName',this.registerForm.value.firstName)
    localStorage.setItem('LastName',this.registerForm.value.lastName)
    localStorage.setItem('DateOfBirth',this.registerForm.value.dateOfBirth)
    localStorage.setItem('Email',this.registerForm.value.email)
    localStorage.setItem('Password',this.registerForm.value.password)
   // localStorage.setItem('Password',this.registerForm.value.password)

    alert("check the values")
    console.table("First-Name is :"+this.registerForm.value.firstName);
    console.table("Last-Name is :"+this.registerForm.value.lastName);
    console.table("Dateof-Birth is :"+this.registerForm.value.dateOfBirth);
    console.table("Email is :"+this.registerForm.value.email);
    console.table("Password is :"+this.registerForm.value.password);
    // console.table("Password is :"+this.registerForm.value.confirmPassword);
  // console.table("Profile-Picture is :"+this.registerForm.value.profilepicture);
    
  }
           
  url="./assets/gall.jpg";
  onselectFile(deepak)
  {
       if(deepak.target.files)
       {
         var render= new FileReader();
         render.readAsDataURL(deepak.target.files[0]);
         render.onload=(event:any)=>{
           this.url=event.target.result;
         }
       }
  }

}
