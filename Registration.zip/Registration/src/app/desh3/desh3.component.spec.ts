import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Desh3Component } from './desh3.component';

describe('Desh3Component', () => {
  let component: Desh3Component;
  let fixture: ComponentFixture<Desh3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Desh3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Desh3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
