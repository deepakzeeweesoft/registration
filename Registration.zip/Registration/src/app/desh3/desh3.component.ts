import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desh3',
  templateUrl: './desh3.component.html',
  styleUrls: ['./desh3.component.css']
})
export class Desh3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
